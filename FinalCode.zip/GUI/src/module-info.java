module GUI {
	requires itextpdf;
	requires java.xml.crypto;
	requires jdk.hotspot.agent;
	requires java.compiler;
	requires java.desktop;
	requires java.smartcardio;
	
}